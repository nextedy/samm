Nextedy Security Assessment Kit
================================

Nextedy Security Assessment Kit delivers a set of Polarion Extensions, Templates and Reports to enable support of Software Assurance Maturity Model (SAMM) implementation in Polarion ALM.

Licensing: Commercial (see LICENSE.pdf), 30day Evaluation license included in the download. 

Requirements: Polarion 18.0+ 

Installation: See INSTALL.txt 

Author: Nextedy Systems https://www.nextedy.com 
For information about licensing and pricing, please contact us at info@nextedy.com
