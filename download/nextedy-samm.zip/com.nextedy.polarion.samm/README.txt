SAMM Solution
=====================

Template for SAMM...

Licensing: Commercial (see LICENSE.pdf), 30day Evaluation license included in the download. 

Requirements: Polarion 18.0+ 

Installation: See INSTALL.txt 

Author: Nextedy Systems https://www.nextedy.com 
For information about licensing and pricing, please contact us at info@nextedy.com
