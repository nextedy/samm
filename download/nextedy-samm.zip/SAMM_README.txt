com.nextedy.polarion.samm
===========================
Detailed README: com.nextedy.polarion.samm/README.txt
Installation instructions: com.nextedy.polarion.gantt/INSTALL.txt
Licensing information: com.nextedy.polarion.gantt/LICENSE.pdf

